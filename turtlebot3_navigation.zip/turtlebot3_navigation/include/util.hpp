// source : https://github.com/mech0ctopus/rrt-global-planner/blob/main/include/2d_space.hpp

#include <math.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <geometry_msgs/Point.h>

#define TWO_M_PI 2 * M_PI
#define M_PI_10 M_PI / 10.

double randomDouble(double fmin, double fmax)
{
    double f = (double) rand() /RAND_MAX;
    return fmin + f * (fmax - fmin);
}

double getDistance(const geometry_msgs::Point point1, const geometry_msgs::Point point2)
{
    double distance = sqrt(pow(point2.y-point1.y, 2) + pow(point2.x -point1.x, 2));
    return distance;

}

bool inFreeSpace(const geometry_msgs::Point point, const costmap_2d::Costmap2DROS* costmap_ros, const double robot_radius_max)
{
    bool result{1};
    double theta{0};
    double robot_radius_ii{robot_radius_max};
    double robot_radius_step{0.05};
    costmap_2d::Costmap2D* costmap_;
    geometry_msgs::Point point_to_check;
    unsigned int mx , my;
    std::vector<costmap_2d::MapLocation> map_polygon, polygon_cells;
    costmap_ = costmap_ros ->getCostmap();

    while(theta <= TWO_M_PI)
    {
        costmap_2d::MapLocation map_loc;

        if(!costmap_ -> worldToMap(point.x + robot_radius_max * cos(theta), point.y + robot_radius_max *sin(theta),
                        map_loc.x, map_loc.y))
            {
                return false;
            }
        map_polygon.push_back(map_loc);

        theta += M_PI_10;
    }
    costmap_ -> convexFillCells(map_polygon, polygon_cells);

    for (unsigned int i = 0; i < polygon_cells.size(); ++i)
    {
        if(costmap_->getCost(polygon_cells[i].x, polygon_cells[i].y) >=costmap_2d::INSCRIBED_INFLATED_OBSTACLE)
        {
            result = 0;
            break;
        }
    }
    return result;

}

bool edgeInFreeSpace(const std::vector<geometry_msgs::Point> edge, costmap_2d::Costmap2DROS* costmap_ros, const double robot_radius)
{
    bool result{1};

    double dist = getDistance(edge[0], edge[1]);

    double num_points = dist / robot_radius;

    geometry_msgs::Point edge_pt_ii{};

    for (double ii = 0; ii <= num_points; ii++){
        edge_pt_ii.x = edge[0].x + ii * (edge[1].x - edge[0].x) / num_points;

        edge_pt_ii.y = edge[0].y + ii * (edge[1].y - edge[0].y) / num_points;

        if (!inFreeSpace(edge_pt_ii, costmap_ros, robot_radius))
        {
            result = 0;
            break;
        }
    }
    return result;
}

geometry_msgs::Point getRandomState (costmap_2d::Costmap2DROS* costmap_ros, const double robot_radius)
{
    geometry_msgs::Point randomState{};
    randomState.z = 0.0;
    costmap_2d::Costmap2D* costmap_;
    costmap_ = costmap_ros -> getCostmap();

    bool pointIsFree{0};

    double origin_x = costmap_->getOriginX();
    double origin_y = costmap_->getOriginY();

    while(!pointIsFree)
    {
        randomState.x = randomDouble(origin_x, origin_x + costmap_->getSizeInMetersX());
        randomState.y = randomDouble(origin_y, origin_y + costmap_->getSizeInMetersY());
        pointIsFree = inFreeSpace(randomState, costmap_ros, robot_radius);

    }

    return randomState;

}










